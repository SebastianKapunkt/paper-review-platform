Credits 2017 
Cagler Özel s0532686,
Sebastian Kindt s0555665

We recommend to read the documentation as markdown inpredeted and not from the pdf. Otherwise you would miss the awesome GIF! ;-)